# -*- coding: utf-8 -*-
"""
Created on Mon Oct 25 08:47:29 2021

@author: Bunnyyyyyyy
"""
import pandas as pd
def count_df(df):
    c_df=df.count()
    return c_df[0]

df1= pd.DataFrame({
            'marks':[1,2,3]
            })

print(count_df(df1))