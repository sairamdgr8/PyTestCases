import unittest
import Base_code
from pandas.testing import *
import pandas as pd

class TestDemo(unittest.TestCase):
    def test_of_records(self):
        # arrange
        df= pd.DataFrame({
            'marks':[1,2,3]
            })
        expected_df=pd.DataFrame({
           'marks':[10,20,30] 

        })
 
        # act
        actual_df=Base_code.mutiplication_df(df)
        # assert
        assert_frame_equal(expected_df,actual_df)
    def count_of_records(self):
        df1= pd.DataFrame({
            'marks':[1,2,3]
            })
        
        expected_df1=3
        actual_df1=Base_code.count_df(df1)
        self.assertEqual(expected_df1,actual_df1)

suite = unittest.TestLoader().loadTestsFromTestCase(TestDemo)
#Running test cases using Test Cases Suit..
unittest.TextTestRunner(verbosity=2).run(suite)

#if __name__ == '__main__':
#    unittest.main()


