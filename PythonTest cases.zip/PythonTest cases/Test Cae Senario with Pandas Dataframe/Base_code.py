def mutiplication_df(df):
    columns=df.columns
    for i in columns:
        df[i]=df[i]*10
    return df

def count_df(df):
    c_df=df.count()
    return c_df[0]
