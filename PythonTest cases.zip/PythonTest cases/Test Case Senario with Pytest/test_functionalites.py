# -*- coding: utf-8 -*-
"""
Created on Fri Oct 22 23:25:01 2021

@author: Bunnyyyyyyy
"""
import pytest
import func


def test_add_method():
    assert func.test_addition(2,2) == 4
    
### to run the code use ----  !pytest test_functionalites.py in the console     