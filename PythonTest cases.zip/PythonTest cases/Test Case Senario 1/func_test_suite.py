# -*- coding: utf-8 -*-
"""
Created on Fri Oct 22 19:04:22 2021

@author: Bunnyyyyyyy
"""

import unittest 
import func
from pandas.testing import *
import pandas as pd

#Creating Class for Unit Testing
class test_class(unittest.TestCase):
    def test_add(self):
        self.assertEqual(10, func.addition(7, 3))
    def test_multi(self):
        self.assertEqual(25,func.multiplication(5,5))
    def test_of_records(self):
        # arrange
        df= pd.DataFrame({
            'marks':[1,2,3]
            })
        expected_df=pd.DataFrame({
           'marks':[10,20,30] 
           })
        # act
        actual_df=func.mutiplication_df(df)
        # assert
        assert_frame_equal(expected_df,actual_df)
    def test_count_of_records(self):
        df1= pd.DataFrame({
            'marks':[1,2,3]
            })
        
        expected_df1=3
        actual_df1=func.count_df(df1)
        self.assertEqual(expected_df1,actual_df1)
    
# create a test suite  for test_class using  loadTestsFromTestCase()
suite = unittest.TestLoader().loadTestsFromTestCase(test_class)
#Running test cases using Test Cases Suit..
unittest.TextTestRunner(verbosity=2).run(suite)


### points to remeber is 
## 1) each test case class should have name with prefix as test_ 
## 2) each test case class having methods to be name with prefix test_