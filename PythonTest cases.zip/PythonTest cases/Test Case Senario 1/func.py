# -*- coding: utf-8 -*-
"""
Created on Fri Oct 22 23:24:07 2021

@author: Bunnyyyyyyy
"""
# -*- coding: utf-8 -*-
"""
Created on Fri Oct 22 19:02:38 2021

@author: Bunnyyyyyyy
"""
def addition(a,b):
    return a+b
def multiplication(a,b):
    return a*b
def mutiplication_df(df):
    columns=df.columns
    for i in columns:
        df[i]=df[i]*10
    return df
def count_df(df):
    c_df=df.count()
    return c_df[0]